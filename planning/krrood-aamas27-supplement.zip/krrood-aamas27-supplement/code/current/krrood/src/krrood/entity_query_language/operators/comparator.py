"""
Comparators for the Entity Query Language.

This module provides binary comparison operators that evaluate relationships between
symbolic expressions, including equality, ordering, and membership-style checks.
"""

from __future__ import annotations

import operator
from copy import copy
from dataclasses import dataclass

from typing_extensions import (
    Callable,
    Any,
    ClassVar,
    Dict,
    Optional,
    Tuple,
    Iterable,
)

from krrood.entity_query_language.core.base_expressions import (
    OperationResult,
    SymbolicExpression,
    BinaryExpression,
    Selectable,
)
from krrood.entity_query_language.operators.set_operations import (
    PerformsCartesianProduct,
)
from krrood.entity_query_language.utils import is_iterable, make_set


@dataclass(eq=False, repr=False)
class Comparator(BinaryExpression, PerformsCartesianProduct):
    """
    A symbolic equality check that can be used to compare symbolic variables using a
    provided comparison operation.
    """

    left: Selectable
    right: Selectable
    operation: Callable[[Any, Any], bool]
    operation_name_map: ClassVar[Dict[Any, str]] = {
        operator.eq: "==",
        operator.ne: "!=",
        operator.lt: "<",
        operator.le: "<=",
        operator.gt: ">",
        operator.ge: ">=",
    }

    @property
    def _product_operands_(self) -> Tuple[SymbolicExpression, ...]:
        return self.left, self.right

    @property
    def _name_(self):
        if self.operation in self.operation_name_map:
            return self.operation_name_map[self.operation]
        return self.operation.__name__

    def _evaluate__(
        self,
        sources: OperationResult,
    ) -> Iterable[OperationResult]:
        """
        Compares the left and right symbolic variables using the "operation".
        """
        yield from (
            self.get_operation_result(result)
            for result in self._evaluate_product_(sources)
        )

    def get_operation_result(self, child_result: OperationResult) -> OperationResult:
        """
        Evaluate the comparator operation and return the result.

        :param child_result: The current result that has the values for the first and
            second operands.
        :return: The result of the operation.
        """
        left_value, right_value = (
            self.left._process_result_(child_result),
            self.right._process_result_(child_result),
        )
        if (
            self.operation in [operator.eq, operator.ne]
            and is_iterable(left_value)
            and is_iterable(right_value)
        ):
            left_value = make_set(left_value)
            right_value = make_set(right_value)
        comparison_result = self.operation(left_value, right_value)
        bindings = copy(child_result.bindings)
        bindings[self._id_] = comparison_result
        return OperationResult(
            bindings, operand=self, previous_operation_result=child_result
        )

    def _optimize_operands_order_(
        self, sources: Optional[OperationResult]
    ) -> Tuple[SymbolicExpression, SymbolicExpression]:
        left_is_definite = self._operand_contains_definite_query_(self.left)
        right_is_definite = self._operand_contains_definite_query_(self.right)
        if left_is_definite and not right_is_definite:
            return self.left, self.right
        if right_is_definite and not left_is_definite:
            return self.right, self.left
        if sources is not None and any(
            v._id_ in sources.bindings for v in self.right._unique_variables_
        ):
            return self.right, self.left
        else:
            return self.left, self.right

    @staticmethod
    def _operand_contains_definite_query_(operand: SymbolicExpression) -> bool:
        """
        :param operand: A comparator operand.
        :return: Whether the operand is, or contains, a definite (``the``) query, which yields a
            single result and is worth evaluating first.
        """
        from krrood.entity_query_language.query.query import Query
        from krrood.entity_query_language.query.quantifiers import The

        return any(
            isinstance(expression, Query)
            and issubclass(expression._quantifier_builder_.type, The)
            for expression in (operand, *operand._descendants_)
        )


def not_contains(container, item) -> bool:
    """
    The inverted contains operation.

    :param container: The container.
    :param item: The item to test if contained in the container.
    :return:
    """
    return not operator.contains(container, item)
