from __future__ import annotations

import zoneinfo
from dataclasses import dataclass
from typing_extensions import Type, Any, List, TYPE_CHECKING

from sqlalchemy.orm import RelationshipProperty

from krrood.exceptions import DataclassException

if TYPE_CHECKING:
    from krrood.ormatic.data_access_objects.alternative_mappings import FunctionMapping
    from krrood.ormatic.data_access_objects.conversion_order import (
        ConversionOrderConstraint,
    )


@dataclass
class NoGenericError(DataclassException, TypeError):
    """
    Exception raised when the original class for a DataAccessObject subclass cannot be
    determined.

    This exception is typically raised when a DataAccessObject subclass has not been
    parameterized properly, which prevents identifying the original class associated
    with it.
    """

    clazz: Type

    def error_message(self) -> str:
        return f"Cannot determine original class for {self.clazz}."

    def suggest_correction(self) -> str:
        return "did you forget to parameterise the DataAccessObject subclass?"


@dataclass
class NoDAOFoundError(DataclassException, TypeError):
    """
    Represents an error raised when no DAO (Data Access Object) class is found for a
    given class.

    This exception is typically used when an attempt to convert a class into a
    corresponding DAO fails. It provides information about the class and the DAO
    involved.
    """

    obj: Any
    """
    The class that no dao was found for
    """

    def error_message(self) -> str:
        return f"Class {type(self.obj)} does not have a DAO."

    def suggest_correction(self) -> str:
        return (
            "Check that the correct ormatic interface is imported, that the ormatic interfaces are "
            "up to date by running the script that generates the ormatic interface, and that the target class is "
            "actually mapped."
        )


@dataclass
class NoDAOFoundForTypeError(NoDAOFoundError):
    """
    Raised when no DAO class is found for a domain *type* rather than for a concrete
    instance.

    Type-driven lookups (such as EQL translation, which resolves DAOs from variable
    types) store the offending type itself in :attr:`obj`, so the message reports it
    directly instead of its metaclass.
    """

    def error_message(self) -> str:
        return f"No DAO found for type {self.obj}."


@dataclass
class NoDAOFoundForSelectionError(NoDAOFoundError):
    """
    Raised when none of the selected expressions of a query resolve to a DAO-bearing
    type.
    """

    def error_message(self) -> str:
        return f"No DAO could be derived from the selected expressions: {self.obj}."


@dataclass
class NoDAOFoundDuringParsingError(NoDAOFoundError):

    dao: Type
    """
    The DAO class that tried to convert the cls to a DAO if any.
    """

    relationship: RelationshipProperty
    """
    The relationship that tried to create the DAO.
    """

    def error_message(self) -> str:
        return (
            f"Class {type(self.obj)} does not have a DAO. This happened when trying "
            f"to create a dao for {self.dao}) on the relationship {self.relationship} with the "
            f"relationship value {self.obj}. "
            f"Expected a relationship value of type {self.relationship.target if self.relationship else 'Unknown'}."
        )


@dataclass
class UnsupportedRelationshipError(DataclassException, ValueError):
    """
    Raised when a relationship direction is not supported by the ORM mapping.

    This error indicates that the relationship configuration could not be interpreted
    into a domain mapping.
    """

    relationship: RelationshipProperty

    def error_message(self) -> str:
        return f"Unsupported relationship direction for {self.relationship}."

    def suggest_correction(self) -> str:
        return ""


@dataclass
class UncallableFunction(NotImplementedError):
    """
    Exception raised when anonymous functions are reconstructed and then called.
    """

    function_mapping: FunctionMapping
    """
    The mapping that was used to reconstruct the function.
    """

    def __post_init__(self):
        super().__init__(
            f"The reconstructed function was a lambda function and hence cannot be called again. "
            f"The function tried to be reconstructed from {self.function_mapping}"
        )


@dataclass
class UnsupportedColumnType(DataclassException, TypeError):
    """
    Exception raised when a column type is neither a type_mapping nor a builtin
    sqlalchemy type.
    """

    column_type: Type

    def error_message(self) -> str:
        return f"Column type: {self.column_type} is neither a builtin sqlalchemy type nor does it exist in the dict of type_mappings."

    def suggest_correction(self) -> str:
        return ""


@dataclass
class ZoneInfoWithoutKey(DataclassException, ValueError):
    """
    Raised when a timezone that has no IANA key, such as one read from a file, is
    written to the database, where timezones are stored by their key.
    """

    zone: zoneinfo.ZoneInfo
    """
    The timezone that has no key.
    """

    def error_message(self) -> str:
        return f"The timezone {self.zone!r} has no IANA key to store it by."

    def suggest_correction(self) -> str:
        return (
            "create the timezone from its key, e.g. zoneinfo.ZoneInfo('Europe/Berlin')."
        )


@dataclass
class ConversionOrderCycle(DataclassException, ValueError):
    """
    Raised when the alternative mappings of a conversion cannot be put in any order,
    because the orders they ask for form a cycle.
    """

    cycle: List[ConversionOrderConstraint]
    """
    The constraints that close the cycle, each one putting its earlier mapping type
    before its later one.
    """

    def error_message(self) -> str:
        orders = "; ".join(constraint.description() for constraint in self.cycle)
        return f"No order converts these alternative mappings: {orders}."

    def suggest_correction(self) -> str:
        corrections = "; ".join(
            constraint.suggest_correction() for constraint in self.cycle
        )
        return f"break the cycle by one of: {corrections}."
