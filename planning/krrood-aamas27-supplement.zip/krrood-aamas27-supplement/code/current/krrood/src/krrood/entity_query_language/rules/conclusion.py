"""
Conclusion rules for the Entity Query Language.

This module defines side-effecting clauses that adjust outputs or bindings (for example,
Add) during query evaluation.
"""

from __future__ import annotations

from abc import ABC
from dataclasses import dataclass
from functools import cached_property

from typing_extensions import Any, List, Iterable, TypeVar

from krrood.entity_query_language.core.base_expressions import (
    Bindings,
    OperationResult,
    SymbolicExpression,
    Selectable,
    BinaryExpression,
)
from krrood.entity_query_language.core.helpers import unwrap_if_literal
from krrood.entity_query_language.core.variable import Variable


@dataclass(eq=False)
class Conclusion(BinaryExpression, ABC):
    """
    Base for side-effecting/action clauses that adjust outputs (e.g., Set, Add).
    """

    left: Selectable
    """
    The variable being affected by the conclusion.
    """

    right: Any
    """
    The value added or set to the variable by the conclusion.
    """

    def __post_init__(self):

        super().__post_init__()

        current_parent = SymbolicExpression._current_parent_in_context_stack_()
        if current_parent is None:
            current_parent = self._conditions_root_
        self._parent_ = current_parent
        self._parent_._conclusions_.add(self)

    @property
    def variable(self) -> Selectable:
        return self.left

    def __eq__(self, other):
        if not isinstance(other, Conclusion):
            return NotImplemented
        if self.left._id_ != other.left._id_:
            return False
        return unwrap_if_literal(self.right) == unwrap_if_literal(other.right)

    def __hash__(self):
        return hash((self.left._id_, unwrap_if_literal(self.right)))

    @property
    def value(self) -> Any:
        return self.right

    @property
    def unwrapped_value(self) -> Any:
        """:return: The right-hand value with any :class:`Literal` wrapper removed."""
        return unwrap_if_literal(self.right)

    @property
    def _name_(self) -> str:
        value_str = (
            self.value._type_.__name__
            if isinstance(self.value, Variable)
            else str(self.value)
        )
        return f"{self.__class__.__name__}({self.variable._var_._name_}, {value_str})"


@dataclass(eq=False)
class Add(Conclusion):
    """
    Add a new value to the domain of a variable.
    """

    def _evaluate__(
        self,
        sources: OperationResult,
    ) -> Iterable[OperationResult]:

        v = next(self.value._evaluate_(sources)).value
        new_bindings = sources.bindings | {self.variable._id_: v}
        yield OperationResult(new_bindings, self, sources)


ConclusionType = TypeVar("ConclusionType", bound=Conclusion)
"""
Type variable bound to :class:`Conclusion` for typed conclusion lookups.
"""
