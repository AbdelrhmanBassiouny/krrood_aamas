from __future__ import annotations

import hashlib
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from functools import cached_property, lru_cache
from inspect import isclass

import sqlalchemy
from typing_extensions import (
    List,
    Dict,
    TYPE_CHECKING,
    Optional,
    Set,
    Type,
    get_origin,
)

from krrood.ormatic.field_storage import FieldStorage
from krrood.ormatic.data_access_objects.alternative_mappings import AlternativeMapping
from krrood.class_diagrams.class_diagram import (
    WrappedClass,
    Inheritance,
)
from krrood.class_diagrams.exceptions import ClassIsUnMappedInClassDiagram
from krrood.class_diagrams.wrapped_field import WrappedField
from krrood.utils import module_and_class_name
from krrood.patterns.caching import memoize

if TYPE_CHECKING:
    from krrood.ormatic.ormatic import ORMatic


logger = logging.getLogger(__name__)


@dataclass
class WrappedTableNotFound(KeyError):
    type_: Type
    wrapped_field: WrappedField

    def __post_init__(self):
        super().__init__(
            f"Didnt find a wrapped table for the type {self.type_}. "
            f"This happened when trying to get a wrapped table for the wrapped field {self.wrapped_field}"
        )


@dataclass
class ColumnConstructor:
    """
    Represents a column constructor that can be used to create a column in SQLAlchemy.
    """

    name: str
    """
    The name of the column.
    """

    type: str
    """
    The type of the column.

    Needs to be like "Mapped[<type>]".
    """

    constructor: Optional[str] = None
    """
    The constructor call for sqlalchemy of the column.
    """

    def __str__(self) -> str:
        if self.constructor:
            return f"{self.name}: {self.type} = {self.constructor}"
        else:
            return f"{self.name}: {self.type}"


@dataclass
class AssociationObject:
    """
    Represents an association object for many-to-many relationships in SQLAlchemy that
    can be rendered with jinja.
    """

    name: str
    """
    The name of the association table.
    """

    left_table_name: str
    """
    The name of the left (source) table.
    """

    left_foreign_key: str
    """
    The foreign key column name for the left table.
    """

    left_primary_key: str
    """
    The full primary key reference for the left table (e.g., 'TableName.primary_key').
    """

    right_table_name: str
    """
    The name of the right (target) table.
    """

    right_foreign_key: str
    """
    The foreign key column name for the right table.
    """

    right_primary_key: str
    """
    The full primary key reference for the right table (e.g., 'TableName.primary_key').
    """

    primary_key_name: Optional[str] = None
    """
    The name of the primary key column, if any.
    """

    @property
    def table_name(self):
        """
        :return: The table name encoded as a hash that is stable across different python processes.
        This needs to happen this way as it is very likely that association table names will get too long for common SQL
        dialects.
        """
        number = int(hashlib.sha256(str(self.name).encode("utf-8")).hexdigest(), 16)
        short_number = str(number)[:62]
        return f"_{short_number}"

    @property
    def primary_key(self) -> ColumnConstructor:
        """
        :return: The primary key column constructor for this association table.
        """
        return ColumnConstructor(
            self.primary_key_name,
            "Mapped[int]",
            "mapped_column(Integer, primary_key=True)",
        )

    @property
    def columns(self) -> List[ColumnConstructor]:
        """
        :return: The foreign key column constructors for the left and right sides.
        """
        return [
            ColumnConstructor(
                self.left_foreign_key,
                "Mapped[int]",
                f"mapped_column(ForeignKey('{self.left_primary_key}'))",
            ),
            ColumnConstructor(
                self.right_foreign_key,
                "Mapped[int]",
                f"mapped_column(ForeignKey('{self.right_primary_key}'))",
            ),
        ]

    @property
    def relationships(self) -> List[ColumnConstructor]:
        """
        :return: The relationship constructors for this association table.
        """
        return [
            ColumnConstructor(
                "target",
                f"Mapped[{self.right_table_name}]",
                f"relationship('{self.right_table_name}', foreign_keys=[{self.right_foreign_key}], lazy='selectin')",
            )
        ]


class TableLike(ABC):
    """
    Common interface of :class:`WrappedTable` and :class:`ExternalTable`: something that
    names a SQLAlchemy table, whether generated in this run or already mapped by a
    dependency.
    """

    @property
    @abstractmethod
    def tablename(self) -> str: ...

    @property
    @abstractmethod
    def qualified_reference(self) -> str: ...

    @property
    @abstractmethod
    def primary_key_name(self) -> str: ...

    @property
    def full_primary_key_name(self) -> str:
        return f"{self.tablename}.{self.primary_key_name}"

    @property
    @abstractmethod
    def qualified_full_primary_key_name(self) -> str: ...


@dataclass
class ExternalTable(TableLike):
    """
    A lookup-only stand-in for a class already mapped by an ormatic-interface
    dependency.

    It is never rendered by the generator — its columns already exist in the
    dependency's generated file. It exists purely so that local tables which use it as a
    foreign key target, relationship target, or parent class can resolve it, the same
    way they would resolve a locally generated :class:`WrappedTable`.
    """

    wrapped_clazz: WrappedClass
    """
    The wrapped (domain) class that this stands in for.
    """

    dao_class: Type
    """
    The ``DataAccessObject`` subclass that already maps ``wrapped_clazz`` in the
    dependency's generated interface.
    """

    @property
    def tablename(self) -> str:
        return self.dao_class.__name__

    @property
    def qualified_reference(self) -> str:
        return module_and_class_name(self.dao_class)

    @cached_property
    def primary_key_name(self) -> str:
        return sqlalchemy.inspect(self.dao_class).primary_key[0].name

    @property
    def qualified_full_primary_key_name(self) -> str:
        return f"{self.qualified_reference}.{self.primary_key_name}"

    @cached_property
    def mapped_field_names(self) -> Set[str]:
        """
        :return: Every ORM attribute name already mapped on ``dao_class``, including
            ones inherited from its own (possibly external) ancestors.
        """
        return {prop.key for prop in sqlalchemy.inspect(self.dao_class).attrs}


@dataclass
class WrappedTable(TableLike):
    """
    A class that wraps a dataclass and contains all the information needed to create a
    SQLAlchemy table from it.
    """

    wrapped_clazz: WrappedClass
    """
    The wrapped class that this table wraps.
    """

    ormatic: ORMatic
    """
    Reference to the ORMatic instance that created this WrappedTable.
    """

    builtin_columns: List[ColumnConstructor] = field(default_factory=list, init=False)
    """
    List of columns that can be directly mapped using builtin types.
    """

    custom_columns: List[ColumnConstructor] = field(default_factory=list, init=False)
    """
    List for custom columns that need to by fully qualified as triple of (name, type,
    constructor)
    """

    foreign_keys: List[ColumnConstructor] = field(default_factory=list, init=False)
    """
    List of columns that represent foreign keys as triple of (name, type, constructor)
    """

    relationships: List[ColumnConstructor] = field(default_factory=list, init=False)
    """
    List of relationships that should be added to the table.
    """

    mapper_args: Dict[str, str] = field(default_factory=dict, init=False)
    """
    Keyword Arguments for the sqlalchemy mapper.
    """

    primary_key_name: str = "database_id"
    """
    The name of the primary key column.
    """

    polymorphic_on_name: str = "polymorphic_type"
    """
    The name of the column that will be used to identify polymorphic identities if any
    present.
    """

    skip_fields: List[WrappedField] = field(default_factory=list)
    """
    A list of fields that should be skipped when processing the dataclass.
    """

    @property
    def primary_key(self):
        if self.parent_table is not None:
            column_type = (
                f"ForeignKey({self.parent_table.qualified_full_primary_key_name})"
            )
        else:
            column_type = "Integer"

        return ColumnConstructor(
            self.primary_key_name,
            f"Mapped[{module_and_class_name(int)}]",
            f"mapped_column({column_type}, primary_key=True, use_existing_column=True)",
        )

    def create_mapper_args(self):
        # every root is unconditionally polymorphic-ready: a downstream package can subclass it
        if self.parent_table is None:
            self.custom_columns.append(
                (
                    ColumnConstructor(
                        self.polymorphic_on_name,
                        "Mapped[str]",
                        "mapped_column(String(255), nullable=False, use_existing_column=True)",
                    )
                )
            )
            self.mapper_args.update(
                {
                    "'polymorphic_on'": f"'{self.polymorphic_on_name}'",
                    "'polymorphic_identity'": f"'{self.tablename}'",
                }
            )

        # this inherits from something
        if self.parent_table is not None:
            self.mapper_args.update(
                {
                    "'polymorphic_identity'": f"'{self.tablename}'",
                    "'inherit_condition'": f"{self.primary_key_name} == {self.parent_table.qualified_full_primary_key_name}",
                    # batch subclass-table loads instead of one SELECT per instance
                    "'polymorphic_load'": "'selectin'",
                }
            )

    @property
    def qualified_reference(self) -> str:
        return self.tablename

    @property
    def qualified_full_primary_key_name(self) -> str:
        return self.full_primary_key_name

    @cached_property
    def tablename(self):
        result = self.wrapped_clazz.name
        result += "DAO"
        return result

    @cached_property
    def parent_table(self) -> Optional[TableLike]:
        """
        Resolve the parent DAO table for this table.

        This first tries to use a direct inheritance relation from the class diagram. If
        that is not available, it tries to find a parent via MRO. If that is not
        available and this table is an alternative mapping, it resolves the parent
        through the original classes' inheritance and maps back to the correct DAO
        table.

        :return: The parent ``WrappedTable`` or ``None`` if there is no parent.
        """
        # Try finding parent via inheritance graph in class diagram
        try:
            inheritance_parents = (
                self.ormatic.class_dependency_graph._dependency_graph.predecessors(
                    self.wrapped_clazz.index
                )
            )
            for parent_wrapped in inheritance_parents[::-1]:
                # Check if this parent has a wrapped table and if the relation is Inheritance
                # We need to check the actual relation object
                edge_data = (
                    self.ormatic.class_dependency_graph._dependency_graph.get_edge_data(
                        parent_wrapped.index, self.wrapped_clazz.index
                    )
                )

                if isinstance(edge_data, Inheritance) and (
                    parent_wrapped in self.ormatic.wrapped_tables
                    or parent_wrapped in self.ormatic.external_tables
                ):
                    return self.ormatic.table_for(parent_wrapped)
        except (AttributeError, KeyError):
            pass

        direct_parent = self._find_direct_parent_wrapped()
        if direct_parent is not None:
            return self.ormatic.table_for(direct_parent)

        if not self.is_alternatively_mapped:
            return None

        original = self._original_wrapped_for_mapping(self.wrapped_clazz)
        if original is None:
            return None

        original_parent = self._find_original_parent_wrapped(original)
        if original_parent is None:
            return None

        resolved_parent_wrapped = self._resolve_alternative_parent_wrapped(
            original_parent
        )
        key = self._to_wrapped_tables_key(resolved_parent_wrapped)
        # the resolved parent may itself be mapped by a dependency rather than locally
        if (
            key not in self.ormatic.wrapped_tables
            and key not in self.ormatic.external_tables
        ):
            return None
        return self.ormatic.table_for(key)

    # %% helper methods

    def _find_direct_parent_wrapped(self) -> Optional[WrappedClass]:
        """
        Return the first mapped parent ``WrappedClass`` from the MRO.

        This iterates through the MRO (Method Resolution Order) of the class and returns
        the first parent class that has a corresponding wrapped table.
        """
        # Get the actual class from wrapped_clazz
        current_class = self.wrapped_clazz.clazz

        # Handle GenericAlias which doesn't have __mro__
        origin = get_origin(current_class)
        if origin is not None and not isinstance(current_class, type):
            mro = origin.__mro__
        else:
            try:
                mro = current_class.__mro__
            except AttributeError:
                return None

        # Iterate through MRO, skipping the first element (the class itself)
        for parent_class in mro[1:]:
            # Skip object base class
            if parent_class is object:
                continue

            # Try to get the wrapped class for this parent
            try:
                parent_wrapped = self.ormatic.class_dependency_graph.get_wrapped_class(
                    parent_class
                )
            except ClassIsUnMappedInClassDiagram:
                # Skip classes that are not in the class diagram
                continue

            # Check if this wrapped class exists in wrapped_tables or external_tables
            if parent_wrapped is not None and (
                parent_wrapped in self.ormatic.wrapped_tables
                or parent_wrapped in self.ormatic.external_tables
            ):
                return parent_wrapped

        return None

    def _original_wrapped_for_mapping(
        self, mapping_wrapped: WrappedClass
    ) -> Optional[WrappedClass]:
        """
        :param mapping_wrapped: The mapping class as a ``WrappedClass``.
        :return: The original class ``WrappedClass`` for an alternative mapping.
        """
        for rel in self.ormatic.alternatively_maps_relations:
            if rel.source == mapping_wrapped:
                return rel.target
        return None

    def _find_original_parent_wrapped(
        self, original_wrapped: WrappedClass
    ) -> Optional[WrappedClass]:
        """
        :param original_wrapped: The original class wrapped node.
        :return: The original parent ``WrappedClass`` of the given original class.
        """
        original_parents = self.ormatic.inheritance_graph.predecessors(
            original_wrapped.index
        )
        if len(original_parents) == 0:
            return None
        return self.ormatic.class_dependency_graph._dependency_graph[
            original_parents[0]
        ]

    def _resolve_alternative_parent_wrapped(
        self, original_parent_wrapped: WrappedClass
    ) -> WrappedClass:
        """
        Return the mapping parent if available, otherwise the original parent.

        :param original_parent_wrapped: The original parent wrapped node.
        :return: The wrapped node to use as parent in DAO generation.
        """
        alt_parent = self.ormatic.get_alternative_mapping(original_parent_wrapped)
        return alt_parent if alt_parent is not None else original_parent_wrapped

    def _to_wrapped_tables_key(self, wrapped: WrappedClass) -> WrappedClass:
        """
        Translate a mapping wrapped node to the original wrapped for table lookup.

        ``wrapped_tables`` are keyed by the original class nodes, even if an alternative
        mapping is used. This ensures we always use the correct key.
        """
        origin = get_origin(wrapped.clazz)
        actual_cls = (
            origin
            if (origin is not None and not isinstance(wrapped.clazz, type))
            else wrapped.clazz
        )

        try:
            is_alt_mapping = issubclass(actual_cls, AlternativeMapping)
        except TypeError:
            is_alt_mapping = False

        if is_alt_mapping:
            for rel in self.ormatic.alternatively_maps_relations:
                if rel.source == wrapped:
                    return rel.target
        return wrapped

    @property
    def is_alternatively_mapped(self):

        origin = get_origin(self.wrapped_clazz.clazz)
        actual_cls = (
            origin
            if (origin is not None and not isinstance(self.wrapped_clazz.clazz, type))
            else self.wrapped_clazz.clazz
        )
        try:
            return issubclass(actual_cls, AlternativeMapping)
        except TypeError:
            return False

    @cached_property
    def fields(self) -> List[WrappedField]:
        """
        :return: The list of fields specified only in this associated dataclass that should be mapped.
        """
        # Collect all inherited mapped field names up the chain
        inherited_mapped_names: set[str] = set()
        p = self.parent_table
        while p is not None:
            if isinstance(p, ExternalTable):
                # Its dependency's own ancestry (local or external) is already baked
                # into its live mapped attributes, so one introspection covers it all.
                inherited_mapped_names.update(p.mapped_field_names)
                break
            # Check what the parent actually created
            inherited_mapped_names.update(c.name for c in p.builtin_columns)
            inherited_mapped_names.update(c.name for c in p.custom_columns)
            inherited_mapped_names.update(c.name for c in p.foreign_keys)
            inherited_mapped_names.update(c.name for c in p.relationships)
            p = p.parent_table

        # Keep only fields that are not inherited by name
        result = [
            f
            for f in self.wrapped_clazz.fields
            if f.field.name not in inherited_mapped_names
        ]

        # If the parent table is alternatively mapped, drop fields that do not exist
        # in the original parent class (compare by name as well). An external parent's
        # `mapped_field_names` above already reflects exactly what it maps, so this
        # reconciliation only applies to locally generated parents.
        if (
            isinstance(self.parent_table, WrappedTable)
            and self.parent_table.is_alternatively_mapped
        ):
            og_parent_class = self.parent_table.wrapped_clazz.clazz.original_class()
            wrapped_og_parent_class = (
                self.ormatic.class_dependency_graph.get_wrapped_class(og_parent_class)
            )

            og_parent_field_names = {
                f.field.name for f in wrapped_og_parent_class.fields
            }
            parent_dao_field_names = {f.field.name for f in self.parent_table.fields}

            # Fields present in original parent class but removed by the DAO mapping
            removed_by_dao = og_parent_field_names - parent_dao_field_names
            result = [r for r in result if r.field.name not in removed_by_dao]

        return result

    @memoize
    def parse_fields(self):

        for f in self.fields:

            logger.info("=" * 80)
            logger.info(
                f"Processing Field {self.wrapped_clazz.clazz.__name__}.{f.field.name}: {f.field.type}."
            )

            # skip private fields
            if f.field.name.startswith("_"):
                logger.info(f"Skipping since the field starts with _.")
                continue

            self.parse_field(f)

        self.create_mapper_args()

    def parse_field(self, wrapped_field: WrappedField):
        """
        Create the column or relationship that stores the field, in the way the ORMatic
        field classifier decides on.

        :param wrapped_field: The field to store.
        """
        storage = self.ormatic.field_classifier.classify(wrapped_field)
        if storage is FieldStorage.NOT_STORED:
            return
        column_creators = {
            FieldStorage.TYPE: self.create_type_type_column,
            FieldStorage.BUILTIN: self.create_builtin_column,
            FieldStorage.MANY_TO_ONE: self.create_one_to_one_relationship,
            FieldStorage.MANY_TO_MANY: self.create_many_to_many_relationship,
            FieldStorage.CUSTOM_TYPE: self.create_custom_type,
            FieldStorage.JSON: self.create_json_column,
        }
        column_creators[storage](wrapped_field)

    def create_builtin_column(self, wrapped_field: WrappedField):
        """
        Creates a built-in column mapping for the given wrapped field.

        Depending on the properties of the `wrapped_field`, this function determines
        whether it's an enum, a built-in type, or requires additional imports. It then
        constructs appropriate column definitions and adds them to the respective list
        of database mappings.

        :param wrapped_field: The WrappedField instance representing the field to create
            a built-in column for.
        """
        self.ormatic.imported_modules.add(wrapped_field.type_endpoint.__module__)
        inner_type = module_and_class_name(wrapped_field.type_endpoint)
        type_annotation = (
            f"{module_and_class_name(Optional)}[{inner_type}]"
            if wrapped_field.is_optional
            else inner_type
        )

        if wrapped_field.type_endpoint is str:
            constructor = f"mapped_column({module_and_class_name(sqlalchemy.types.Text)}, use_existing_column=True)"
        else:
            constructor = f"mapped_column(use_existing_column=True)"
        self.builtin_columns.append(
            ColumnConstructor(
                name=wrapped_field.field.name,
                type=f"Mapped[{type_annotation}]",
                constructor=constructor,
            )
        )

    def create_type_type_column(self, wrapped_field: WrappedField):
        """
        Create a column for a field of type `Type`.

        :param wrapped_field: The field to extract type information from.
        :return:
        """
        column_name = wrapped_field.field.name
        column_type = (
            f"Mapped[TypeType]"
            if not wrapped_field.is_optional
            else f"Mapped[{module_and_class_name(Optional)}[TypeType]]"
        )
        column_constructor = f"mapped_column(TypeType, nullable={wrapped_field.is_optional}, use_existing_column=True)"
        self.custom_columns.append(
            ColumnConstructor(column_name, column_type, column_constructor)
        )

    def get_table_of_wrapped_field(self, wrapped_field: WrappedField) -> TableLike:
        """
        :param wrapped_field: The wrapped field to get the table for.
        :return: The wrapped table for the given wrapped field.
        """
        type_endpoint = wrapped_field.type_endpoint
        try:
            return self.ormatic.table_for(
                self.ormatic.class_dependency_graph.get_wrapped_class(type_endpoint)
            )
        except KeyError:
            raise WrappedTableNotFound(type_=type_endpoint, wrapped_field=wrapped_field)

    def create_one_to_one_relationship(self, wrapped_field: WrappedField):
        """
        Create a one-to-one relationship with using the given field.

        This adds a foreign key and a relationship to this table.

        :param wrapped_field: The field to get the information from.
        """
        # create foreign key
        fk_name = f"_{wrapped_field.field.name}{self.ormatic.foreign_key_postfix}"
        fk_type = (
            f"Mapped[{module_and_class_name(Optional)}[{module_and_class_name(int)}]]"
            if wrapped_field.is_optional
            else "Mapped[int]"
        )

        # get the target table
        target_wrapped_table = self.get_table_of_wrapped_field(wrapped_field)

        # columns have to be nullable and use_alter=True since the insertion order might be incorrect otherwise
        fk_column_constructor = f"mapped_column(ForeignKey('{target_wrapped_table.full_primary_key_name}', use_alter=True), nullable=True, use_existing_column=True)"

        self.foreign_keys.append(
            ColumnConstructor(fk_name, fk_type, fk_column_constructor)
        )

        # create relationship to remote side
        rel_name = f"{wrapped_field.field.name}"
        rel_type = f"Mapped[{target_wrapped_table.tablename}]"
        # relationships have to be post updated since since it won't work in the case of subclasses with another ref otherwise
        # they also stay lazy: eager selectin would cascade through many-to-one
        # cycles at query time; from_dao resolves them via the identity map instead
        rel_constructor = f"relationship('{target_wrapped_table.tablename}', uselist=False, foreign_keys=[{fk_name}], post_update=True)"
        self.relationships.append(
            ColumnConstructor(rel_name, rel_type, rel_constructor)
        )

    def create_many_to_many_relationship(self, wrapped_field: WrappedField):
        """
        Creates a many-to-many relationship mapping for the given wrapped field using an
        association table. This allows multiple instances of the source table to
        reference the same instances of the target table.

        :param wrapped_field: The field for the many-to-many relationship.
        """
        # get the target table
        target_wrapped_table = self.get_table_of_wrapped_field(wrapped_field)

        # create association table name
        association_table_name = (
            f"{self.tablename}_{wrapped_field.field.name}_association"
        )

        # create foreign key names for the association table
        # Always disambiguate sides using source_/target_ prefixes to avoid
        # duplicated column names in self-referential relationships
        left_fk_name = (
            f"_source_{self.tablename.lower()}{self.ormatic.foreign_key_postfix}"
        )
        right_fk_name = f"_target_{target_wrapped_table.tablename.lower()}{self.ormatic.foreign_key_postfix}"

        # create association table metadata
        association_table = AssociationObject(
            name=association_table_name,
            left_table_name=self.tablename,
            left_foreign_key=left_fk_name,
            left_primary_key=self.full_primary_key_name,
            right_table_name=target_wrapped_table.tablename,
            right_foreign_key=right_fk_name,
            right_primary_key=target_wrapped_table.full_primary_key_name,
            primary_key_name="database_id",
        )

        # add association table to ORMatic
        self.ormatic.association_objects.append(association_table)

        # create a relationship
        rel_name = f"{wrapped_field.field.name}"

        # SQLAlchemy instruments a collection class in place (it needs an appender
        # method), which an immutable domain container such as tuple cannot provide.
        # The relationship is therefore held as a list at the ORM layer; from_dao
        # restores the domain field's own tuple type once its object is populated
        # (see DataAccessObject._finalize_object_containers).
        collection_class_type = (
            list
            if wrapped_field.container_type is tuple
            else wrapped_field.container_type
        )
        container_name = module_and_class_name(collection_class_type)

        # Association Object pattern
        rel_type = f"Mapped[{container_name}[{association_table.name}]]"
        rel_constructor = (
            f"relationship('{association_table.name}', "
            f"collection_class={container_name}, "
            f"cascade='all, delete-orphan', "
            f"foreign_keys='[{association_table.name}.{association_table.left_foreign_key}]', "
            f"lazy='selectin')"
        )

        self.relationships.append(
            ColumnConstructor(rel_name, rel_type, rel_constructor)
        )

    def create_json_column(self, wrapped_field: WrappedField):
        """
        Create a JSON column for a value, or a list-like of values, that krrood's JSON
        serializer can write.

        :param wrapped_field: The field to extract the information from.
        """
        type_endpoint = wrapped_field.type_endpoint
        self.ormatic.imported_modules.add("typing_extensions")
        self.ormatic.imported_modules.add(type_endpoint.__module__)
        column_name = wrapped_field.field.name
        value_type = module_and_class_name(type_endpoint)
        if not wrapped_field.is_container:
            column_type = (
                f"Mapped[{module_and_class_name(Optional)}[{value_type}]]"
                if wrapped_field.is_optional
                else f"Mapped[{value_type}]"
            )
        else:
            container = (
                Set
                if isclass(wrapped_field.container_type)
                and issubclass(wrapped_field.container_type, set)
                else List
            )
            column_type = f"Mapped[{module_and_class_name(container)}[{value_type}]]"
        column_constructor = f"mapped_column(JSON, nullable={wrapped_field.is_optional}, use_existing_column=True)"
        self.custom_columns.append(
            ColumnConstructor(column_name, column_type, column_constructor)
        )

    def create_custom_type(self, wrapped_field: WrappedField):
        type_endpoint = wrapped_field.type_endpoint
        custom_type = self.ormatic.type_mappings[type_endpoint]
        self.ormatic.type_mappings[type_endpoint] = custom_type
        self.ormatic.imported_modules.add(type_endpoint.__module__)
        column_name = wrapped_field.field.name
        column_type = (
            f"Mapped[{module_and_class_name(type_endpoint)}]"
            if not wrapped_field.is_optional
            else f"Mapped[{module_and_class_name(Optional)}[{module_and_class_name(type_endpoint)}]]"
        )

        constructor = f"mapped_column({module_and_class_name(custom_type)}, nullable={wrapped_field.is_optional}, use_existing_column=True)"

        self.custom_columns.append(
            ColumnConstructor(column_name, column_type, constructor)
        )

    @property
    def base_class_name(self):
        if self.parent_table is not None:
            return self.parent_table.qualified_reference
        else:
            return "Base"

    def __hash__(self):
        return hash(self.wrapped_clazz)
