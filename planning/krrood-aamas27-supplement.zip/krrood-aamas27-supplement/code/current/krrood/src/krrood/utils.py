from __future__ import annotations

import ast
import builtins
import importlib
import os
import sys
import types
from dataclasses import Field
from dataclasses import fields, MISSING
from functools import lru_cache
from importlib.util import resolve_name
from inspect import isclass
from os import PathLike
from os.path import dirname
from pathlib import Path
from typing import Tuple, Generic, Hashable
from typing import Union, Any

from typing_extensions import (
    Dict,
    get_origin,
    get_args,
)
from typing_extensions import (
    TypeVar,
    Type,
    List,
    Optional,
    Callable,
    TypeVarTuple,
    _SpecialForm,
)

from krrood import logger
from krrood.exceptions import (
    NoModuleSourceProvided,
    NoDefaultValueFound,
    PackageNameNotFoundError,
    PathMissingRequiredPartsError,
    SourceDataNotProvided,
)

T = TypeVar("T")


def recursive_subclasses(cls: Type[T]) -> List[Type[T]]:
    """
    :param cls: The class.
    :return: A list of the classes subclasses without the class itself.
    """
    return cls.__subclasses__() + [
        g for s in cls.__subclasses__() for g in recursive_subclasses(s)
    ]


def get_full_class_name(cls):
    """
    Return the full name of a class, including the module name.

    :param cls: The class.
    :return: The full name of the class
    """
    return cls.__module__ + "." + cls.__name__


def module_and_class_name(type_: Union[Type, _SpecialForm]) -> str:
    """
    :param type_: A class or special form.
    :return: Its fully qualified ``"{module}.{name}"`` identifier.
    """
    return f"{get_module_of_type(type_)}.{type_.__name__}"


def get_module_of_type(type_: Union[Type, _SpecialForm]) -> str:
    """
    :param type_: The type of which the module is obtained.
    :return: The module name of the given type_.
    """
    if type_ is types.NoneType:
        return "types"
    return type_.__module__


def resolve_class_from_full_name(fully_qualified_class_name: str) -> Type:
    """
    Import and return the class named by a fully qualified name of the form
    ``"module.submodule.ClassName"``, as written by :func:`get_full_class_name` or
    :func:`module_and_class_name`.

    :param fully_qualified_class_name: The fully qualified class name.
    :return: The resolved class.
    """
    module_name, class_name = fully_qualified_class_name.rsplit(".", 1)
    module = importlib.import_module(module_name)
    return getattr(module, class_name)


def get_default_value(dataclass_type, field_name):
    """
    Return the default value for a given field in a dataclass.

    :param dataclass_type: The dataclass type to get the default value for.
    :param field_name: The name of the field to get the default value for.
    :return: The default value for the field.
    """
    for f in fields(dataclass_type):
        if f.name != field_name:
            continue
        if f.default is not MISSING:
            return f.default
        elif f.default_factory is not MISSING:  # handles mutable defaults
            return f.default_factory()
        else:
            raise NoDefaultValueFound(dataclass_type, field_name)
    return None


def get_default_values_for_dataclass(dataclass_type):
    """
    Return a dict mapping field names to their default values.

    Only includes fields that actually define a default.

    :param dataclass_type: The dataclass type to get the default values for.
    :return: A dict mapping field names to their default values.
    """
    defaults = {}

    for f in fields(dataclass_type):
        if f.default is not MISSING:
            defaults[f.name] = f.default
        elif f.default_factory is not MISSING:
            defaults[f.name] = f.default_factory()

    return defaults


@lru_cache
def own_dataclass_fields(cls) -> List[Field]:
    """
    :return: The fields of the dataclass that are not inherited from a base class.
    """
    base_fields = set()
    for base in cls.__mro__[1:]:
        if hasattr(base, "__dataclass_fields__"):
            base_fields.update(base.__dataclass_fields__.keys())

    return [f for f in fields(cls) if f.name not in base_fields]


def is_typing_type(type_object: Any):
    """
    :param type_object: A type object to check.
    :return: True if the type is a type from the typing module, False otherwise.
    """
    return hasattr(type_object, "__module__") and type_object.__module__ == "typing"


def is_builtin_type(type_object: Any):
    """
    :param type_object: A type object to check.
    :return: True if the type is a built-in type, False otherwise.
    """
    return (
        isinstance(type_object, type)
        and type_object.__module__ == "builtins"
        and hasattr(builtins, type_object.__name__)
    )


def get_import_root_from_path(path: Path) -> Path:
    """
    Find the directory an import of a path is resolved against.

    :param path: The file system path to find the import root of.
    :return: The nearest ancestor of the path that is not itself a package.
    """
    root = Path(path).resolve()
    while (root / "__init__.py").exists():
        parent = root.parent
        if parent == root:
            break
        root = parent
    return root


def get_import_path_from_path(path: str) -> Optional[str]:
    """
    Convert a file system path to a Python import path.

    :param path: The file system path to convert.
    :return: The Python import path, or None if the path is not inside a package.
    """
    absolute_path = Path(path).resolve()
    root = get_import_root_from_path(absolute_path)
    if root == absolute_path:
        return None
    return str(absolute_path.relative_to(root)).replace(os.path.sep, ".")


def make_path_importable(path: Path) -> None:
    """
    Put the directory an import of a path is resolved against on the search path.

    ..note:: Generated code is written wherever its caller chose, which need not be a
        directory Python already searches, so importing it back requires saying where
        to look for it.

    :param path: The file system path that is about to be imported.
    """
    root = str(get_import_root_from_path(path))
    if root not in sys.path:
        sys.path.insert(0, root)


def get_function_import_data(func: Callable) -> Tuple[str, str]:
    """
    Get the import path of a function.

    :param func: The function to get the import path for.
    :return: The import path of the function.
    """
    func_name = get_method_name(func)
    func_class_name = get_method_class_name_if_exists(func)
    func_file_path = get_method_file_name(func)
    func_file_name = func_file_path.split("/")[-1].split(".")[
        0
    ]  # Get the file name without extension
    func_import_path = get_import_path_from_path(dirname(func_file_path))
    func_import_path = (
        f"{func_import_path}.{func_file_name}" if func_import_path else func_file_name
    )
    if func_class_name and func_class_name != func_name:
        func_import_name = func_class_name
    else:
        func_import_name = func_name
    return func_import_path, func_import_name


def get_method_name(method: Callable) -> str:
    """
    Get the name of a method.

    :param method: The method to get the name of.
    :return: The name of the method.
    """
    return method.__name__ if hasattr(method, "__name__") else str(method)


def get_class_and_attribute_name(class_name: str, attribute_name: str) -> str:
    """
    Return the dot-qualified name ``"{class_name}.{attribute_name}"``.

    :param class_name: The owner class name, typically ``SomeClass.__name__``.
    :param attribute_name: The attribute or variable name to qualify.
    :return: The qualified name string.
    """
    return f"{class_name}.{attribute_name}"


def get_method_class_name_if_exists(method: Callable) -> Optional[str]:
    """
    Get the class name of a method if it has one.

    :param method: The method to get the class name of.
    :return: The class name of the method.
    """
    if hasattr(method, "__self__"):
        if hasattr(method.__self__, "__name__"):
            return method.__self__.__name__
        elif hasattr(method.__self__, "__class__"):
            return method.__self__.__class__.__name__
    return (
        method.__qualname__.split(".")[0]
        if hasattr(method, "__qualname__") and "." in method.__qualname__
        else None
    )


def get_method_file_name(method: Callable) -> str:
    """
    Get the file name of a method.

    :param method: The method to get the file name of.
    :return: The file name of the method.
    """
    return method.__code__.co_filename


def get_relative_import(
    target_file_path: str | PathLike[str],
    imported_module_path: Optional[str] = None,
    module_name: Optional[str] = None,
    package_name: Optional[str] = None,
) -> str:
    """
    Get a relative import path from the target file to the imported module.

    :param target_file_path: The file path of the target file.
    :param imported_module_path: The file path of the module being imported.
    :param module_name: The module name, if available.
    :param package_name: The name of the root package where the module is located.
    :return: A relative import path as a string.
    """
    # Convert to absolute paths
    if module_name is not None:
        imported_module_path = sys.modules[module_name].__file__
    if imported_module_path is None:
        raise NoModuleSourceProvided(
            imported_module_path=imported_module_path, module_name=module_name
        )
    target_path = Path(target_file_path).resolve()
    imported_file_name = Path(imported_module_path).name
    target_file_name = Path(target_file_path).name
    if package_name is not None:
        target_path = Path(
            get_path_starting_from_latest_encounter_of(
                str(target_path), package_name, [target_file_name]
            )
        )
    imported_path = Path(imported_module_path).resolve()
    if package_name is not None:
        imported_path = Path(
            get_path_starting_from_latest_encounter_of(
                str(imported_path), package_name, [imported_file_name]
            )
        )

    # Compute relative path from target to imported module
    rel_path = os.path.relpath(imported_path.parent, target_path.parent)

    # Convert path to Python import format
    rel_parts = [part.replace("..", ".") for part in Path(rel_path).parts]
    rel_parts = rel_parts if rel_parts else [""]
    dot_parts = [part for part in rel_parts if part == "."]
    non_dot_parts = [part for part in rel_parts if part != "."] + [imported_path.stem]

    # Join the parts
    joined_parts = "." + "".join(dot_parts) + ".".join(non_dot_parts)

    return joined_parts


def get_path_starting_from_latest_encounter_of(
    path: str, package_name: str, should_contain: List[str]
) -> str:
    """
    Get the path starting from the package name.

    :param path: The full path to the file.
    :param package_name: The name of the package to start from.
    :param should_contain: The names of the files or directories to look for.
    :return: The path starting from the package name that contains all the names in
        should_contain, otherwise raise an error.
    :raise PackageNameNotFoundError: If the package name could not be found in the path.
    :raise PathMissingRequiredComponentsError: If the path does not contain all the
        names in should_contain.
    """
    path_parts = path.split(os.path.sep)
    if package_name not in path_parts:
        raise PackageNameNotFoundError(package_name, path)
    idx = path_parts.index(package_name)
    prev_idx = idx
    while all(sc in path_parts[idx:] for sc in should_contain):
        prev_idx = idx
        try:
            idx = path_parts.index(package_name, idx + 1)
        except ValueError:
            break
    if all(sc in path_parts[idx:] for sc in should_contain):
        path_parts = path_parts[prev_idx:]
        return os.path.join(*path_parts)
    else:
        raise PathMissingRequiredPartsError(should_contain, path)


def get_generic_type_parameters(
    cls,
    generic_base: Type,
    include_root_generic_base: bool = True,
    include_specialized_generic_base: bool = True,
) -> List[Type[T]]:
    """
    Given a subclass and its generic base, return the concrete type parameter(s).

    Example:
        get_generic_type_parameters(Employee, Role) -> [<class '__main__.Person'>]

    Direct parameterizations (e.g. ``class C(B, Generic[U])``) take priority over
    an inherited binding discovered by recursing into an unparameterized base.

    :param cls: The subclass to check.
    :param generic_base: The generic base class to check against.
    :param include_root_generic_base: Whether to include type parameters the class gets from its own typing.Generic directly.
    :param include_specialized_generic_base: Whether to include type parameters from superclasses that are generic, which are not typing.Generic.
    :return: A list of concrete type parameters
    """
    parameters = []
    if include_root_generic_base:
        # Use __parameters__ to get the class's own unbound TypeVars.
        parameters.extend(list(getattr(cls, "__parameters__", [])))

    if include_specialized_generic_base:
        for base in getattr(cls, "__orig_bases__", []):
            base_origin = get_origin(base)
            if (
                not base_origin
                or base_origin is Generic
                or not issubclass(base_origin, generic_base)
            ):
                continue
            for argument in get_args(base):
                if not isinstance(argument, (TypeVar, TypeVarTuple)):
                    parameters.append(argument)
                elif not include_root_generic_base:
                    # If we specifically excluded root generic parameters, we might still want
                    # TypeVars that are being passed to this specialized base
                    # Example: For `class Child(Generic[T, U], Parent[T])`:
                    # - `include_root_generic_base=True` returns `[T, U]` (captures all definitions, avoids duplicates).
                    # - `include_root_generic_base=False` returns `[T]` (captures only what is specifically passed to `Parent`).
                    parameters.append(argument)

    return parameters


def get_existing_field_by_name(cls, name: str) -> Optional[Field]:
    """
    Find the existing field in the MRO if it exists.

    :param name: The name of the field.
    :return: The existing field if found, otherwise None.
    """
    for base in cls.__mro__:
        fields = getattr(base, "__dataclass_fields__", None)
        if fields and name in fields:
            return fields[name]
    return None


def is_hashable(obj) -> bool:
    """
    Checks if an object is hashable by attempting to compute its hash.

    :param obj: The object to check.
    :return: True if the object is hashable, False otherwise.
    """
    try:
        hash(obj)
        return True
    except TypeError:
        return False


def ensure_hashable(obj) -> Hashable:
    """
    :return: The object itself if it is hashable, otherwise its id.
    """
    if not is_hashable(obj):
        return id(obj)
    return obj


def get_scope_from_imports(
    file_path: Optional[str] = None,
    tree: Optional[ast.AST] = None,
    package_name: Optional[str] = None,
    source: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Create a scope dictionary from imports in a Python file or an AST tree.

    :param file_path: The path to the Python file to extract imports from.
    :param tree: An AST tree to extract imports from. If provided, file_path is ignored.
    :param package_name: The name of the package to use for relative imports.
    :param source: The source code to extract imports from. If provided, file_path and
        tree are ignored.
    :return: A dictionary representing the scope with imported modules and their
        attributes.
    """
    if tree is None and file_path is None and source is None:
        raise SourceDataNotProvided(file_path, tree, source)

    # Ensure we have source and a parsed AST
    if file_path and source is None:
        with open(file_path, "r") as f:
            source = f.read()
    parsed_tree = tree or (
        ast.parse(source)
        if file_path is None
        else ast.parse(source, filename=file_path)
    )

    scope: Dict[str, Any] = {}

    for node in ast.walk(parsed_tree):
        if isinstance(node, ast.Import):
            _handle_import_node(node, scope, package_name)
        elif isinstance(node, ast.ImportFrom):
            package_name = _handle_import_from_node(
                node=node,
                scope=scope,
                file_path=file_path,
                package_name=package_name,
            )

    return scope


def get_and_import_module(
    module_name: str, package_name: Optional[str]
) -> types.ModuleType:
    """
    Attempt to import a module with an optional package context and return the module or
    raise.

    :param module_name: The name of the module to import.
    :param package_name: The package name to use for relative imports, or None for
        absolute imports.
    :return: The imported module.
    :raises ModuleNotFoundError: If the module cannot be found.
    """
    module = get_module_object(module_name, package_name)
    if module is not None:
        return module

    try:
        return importlib.import_module(module_name, package=package_name)
    except ModuleNotFoundError as e:
        if not package_name:
            raise e
        if module_name.startswith(".") and package_name:
            full_name = resolve_name(module_name, package_name)
        else:
            full_name = f"{package_name}.{module_name}"
        if full_name in sys.modules:
            return sys.modules[full_name]
        return importlib.import_module(full_name)


def get_module_object(
    module_name: str, package_name: Optional[str] = None
) -> Optional[types.ModuleType]:
    """
    :param module_name: The name of the module to import.
    :param package_name: The name of the package containing the module.
    :return: The imported module object.
    """
    try:
        full_name = module_name
        if module_name.startswith(".") and package_name:
            full_name = resolve_name(module_name, package_name)

        if full_name in sys.modules:
            return sys.modules[full_name]
    except Exception:
        return None


def _resolve_relative_import(
    file_path: Optional[str],
    node: ast.ImportFrom,
    module_name: Optional[str],
    package_name: Optional[str],
) -> tuple[Optional[str], Optional[str]]:
    """
    Resolve relative import context and possibly adjust module and package names based
    on file location.

    :param file_path: The path to the file containing the import statement.
    :param node: The import from node to process.
    :param module_name: The module name to resolve.
    :param package_name: The package name to use for relative imports.
    :return: a tuple of (resolved_module_name, resolved_package_name).
    """
    resolved_module = module_name
    resolved_package = package_name

    if node.level > 0 and file_path is not None:
        try:
            resolved_package = get_import_path_from_path(
                Path(os.path.join(file_path, *[".."] * node.level)).resolve()
            )
        except Exception:
            # Keep original package if resolution fails
            pass

        if resolved_package is not None and module_name is not None:
            try:
                module_rel_path = Path(
                    os.path.join(file_path, *[".."] * node.level, module_name)
                ).resolve()
                idx = str(module_rel_path).rfind(resolved_package)
                if idx != -1:
                    resolved_module = str(module_rel_path)[idx:].replace(
                        os.path.sep, "."
                    )
            except Exception:
                # Fall back to original module name
                pass

    return resolved_module, resolved_package


def _handle_import_node(
    node: ast.Import, scope: Dict[str, Any], package_name: Optional[str]
) -> None:
    """
    Process a standard import node and update the provided scope mapping.

    :param node: The import node to process.
    :param scope: The scope mapping to update.
    :param package_name: The package name to use for relative imports.
    """
    for alias in node.names:
        module_name = alias.name
        asname = alias.asname or alias.name
        module = get_and_import_module(module_name, package_name)
        scope[asname] = module


@lru_cache(maxsize=None)
def _log_unresolvable_import_once(
    resolved_module_name: Optional[str],
    name: str,
    file_path: Optional[str],
    error_message: str,
) -> None:
    """
    Log, at most once per process for a given ``(resolved_module_name, name,
    file_path)`` triple, that a name could not be imported while extracting a file's
    imports.

    A dataclass field annotated under ``if TYPE_CHECKING:`` with a name from a module
    involved in a circular import can be re-resolved many times while that module is
    still initializing (once per class needing it, and once per lookup attempt). Every
    attempt fails identically and is otherwise harmless, so repeating the warning for
    each attempt only floods the log without adding information; the ``lru_cache``
    collapses repeats of the identical triple to a single log line.

    :param resolved_module_name: The module the failed import targeted.
    :param name: The name that could not be bound from that module.
    :param file_path: The path of the file whose imports were being extracted.
    :param error_message: The message of the error that was raised.
    """
    logger.debug(
        f"Could not import {resolved_module_name}: {error_message} while extracting imports from {file_path}"
    )


def _handle_import_from_node(
    node: ast.ImportFrom,
    scope: Dict[str, Any],
    file_path: Optional[str],
    package_name: Optional[str],
) -> Optional[str]:
    """
    Process a from-import node and update the provided scope mapping.

    A statement whose module cannot be imported contributes no names and is skipped,
    just as a name missing from an imported module is: the scope is built for
    best-effort name resolution, so one statement that cannot be bound must not cost
    the caller every other name in the file.

    ..note:: A module a generator is about to write, such as an ORM interface, is
        absent for exactly as long as that generator runs.

    :param node: The from-import node to process.
    :param scope: The scope mapping to update.
    :param file_path: The path to the file containing the import statement.
    :param package_name: The package name to use for relative imports.
    :return: the (possibly) updated package_name to mimic original behavior.
    """
    module_name = node.module

    # Resolve relative imports (may update package_name and module_name)
    resolved_module_name, resolved_package_name = _resolve_relative_import(
        file_path=file_path,
        node=node,
        module_name=module_name,
        package_name=package_name,
    )

    # Mimic original behavior: allow package_name to be overwritten for subsequent iterations
    package_name = resolved_package_name

    try:
        module = None
        if resolved_module_name is not None:
            module = get_and_import_module(resolved_module_name, package_name)

        if module is None and resolved_package_name and resolved_module_name:
            # Fallback already attempted in _import_module_safely; keep for parity
            module = get_and_import_module(
                f"{resolved_package_name}.{resolved_module_name}", None
            )
    except ModuleNotFoundError as error:
        for alias in node.names:
            _log_unresolvable_import_once(
                resolved_module_name, alias.name, file_path, str(error)
            )
        return package_name

    for alias in node.names:
        name = alias.name
        asname = alias.asname or name
        try:
            if name == "*":
                scope.update(module.__dict__)
            else:
                scope[asname] = getattr(module, name)
        except AttributeError as e:
            _log_unresolvable_import_once(resolved_module_name, name, file_path, str(e))

    return package_name


def is_dynamic_class(cls: Type) -> bool:
    """
    Check if a class is dynamically created.

    This is done by checking if the class is actually registered in that module under
    its own name Normal classes will be found; classes created with  for instance
    make_dataclass  usually won't be unless manually assigned.
    :param cls: The class to check.
    :return: True if the class is dynamically created, False otherwise.
    """
    # Ensure it is a class first
    if not isclass(cls):
        return False

    # Get the module where the class claims to be defined
    module = sys.modules.get(cls.__module__)
    if module is None:
        return True  # If module doesn't exist, it's likely dynamic

    return getattr(module, cls.__name__, None) is not cls
