"""Code generation utilities.


"""
