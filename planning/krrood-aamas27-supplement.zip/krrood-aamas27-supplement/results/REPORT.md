# KRROOD supplementary material: results of the paper's run

Bundle ae0b139a90267579 (code/earlier as in this bundle), Intel Core i7-13700, 64 GB RAM, Ubuntu 24.04. These are the numbers in the paper; a run of this bundle writes the same report with its own numbers next to them. See provenance.txt for which numbers come from which run.

### Table 1. Answers compared with GraphDB's (paper, Section 7.1)

| Query | Answers | SQL | EQL | RDFLib | Owlready2 |
| :--- | ---: | :--- | :--- | :--- | :--- |
| Q2 | 7,421 | equal | equal | equal | equal |
| Q3 | 55 | equal | equal | equal | equal |
| Q4 | 2,486 | equal | equal | equal | equal |
| Q5 | 20 | equal | equal | equal | equal |
| Q7 | 1,684 | equal | equal | equal | equal |
| Q8 | 6 | equal | equal | equal | equal |
| Q9 | 0 | equal | equal | equal | equal |
| Q10 | 666 | equal | equal | equal | equal |
| Q11 | 2,422 | equal | equal | equal | equal |
| Q12 | 2,494 | equal | equal | equal | equal |
| Q13 | 0 | equal | equal | equal | equal |
| Q14 | 0 | equal | equal | equal | equal |
| Q15 | 21 | equal | equal | equal | equal |
| Q16 | 21 | equal | equal | equal | equal |
| Q19 | 858 | equal | equal | equal | equal |
| Q20 | 1,311,932 | equal | equal | equal | equal |
| Q21 | 145 | equal | equal | equal | equal |
| Q22 | 106 | equal | equal | equal | equal |

*Each system's answers to the 18 OWL 2 RL queries of OWL2Bench, normalized to sets of tuples, compared with GraphDB's, from a GraphDB server started in this run, with the OWL 2 RL ruleset. "Answers" is the number of GraphDB's answers; "equal" means the same set; "DIFFERS (-a, +b)" gives the answers missing and extra. In the paper (Section 7.1), all systems are equal on all queries. Result: all equal.*

### Table 2. Knowledge base compared with the OWL 2 RL closure (paper, Section 7.1)

| Assertions | KRROOD | Closure | Extra | Missing |
| :--- | ---: | ---: | ---: | ---: |
| Class memberships | 17,558 | 17,558 | 0 | 0 |
| Object-property assertions | 1,385,869 | 1,385,869 | 0 | 0 |
| Data-property assertions | 20,933 | 20,933 | 0 | 0 |

*KRROOD's knowledge base, loaded from the raw data, compared assertion by assertion with GraphDB's OWL 2 RL closure: "extra" are assertions only in KRROOD (unsound), "missing" only in the closure. The paper reports 0 and 0 for all three. The OWL 2 RL rules that derive equalities or inconsistencies: passed, 0 equalities, 0 inconsistencies (paper: 0 and 0).*

### Table 3. Loading and reasoning (paper, Table 3)

| System | Input | Time [s] | Memory |
| :--- | :--- | ---: | ---: |
| KRROOD | raw | 8.15 ± 0.03 | 209 MB |
| KRROOD | pre-reasoned | 89.2 ± 0.40 | 1.81 GB |
| KRROOD (with ORMatic) | raw | 28.9 ± 0.11 | 1.43 GB |
| KRROOD (with ORMatic) | pre-reasoned | 114 ± 0.38 | 2.90 GB |
| Owlready2 + Pellet | raw | 39.2 ± 0.94 | 2.26 GB |
| Owlready2 + Pellet | pre-reasoned | failed | 2.30 GB |
| RDFLib + owlrl | raw | > 10800 | 5.75 GB |
| RDFLib + owlrl | pre-reasoned | > 10800 | 2.35 GB |
| GraphDB | raw | 1210 | 860 MB |
| GraphDB | pre-reasoned | 748 | 406 MB |
| Protégé + Pellet (by hand) | raw | 4.56 | 2.89 GB |
| Protégé + Pellet (by hand) | pre-reasoned | 16.7 | 3.12 GB |
| KRROOD without step 5 | raw | > 7200 | 638 MB |

*Time in seconds to load the ontology and compute its consequences (mean ± standard deviation over the repetitions), from the raw data (54,901 statements) and from the pre-reasoned data (1,431,635). Memory is the increase during loading: the peak resident set size of the process tree minus that of a fresh worker after its imports; for GraphDB, the increase of its Java heap in use (GC log). "> N" means stopped at the time limit. Times depend on the machine; the paper's are from an Intel Core i7-13700 with 64 GB RAM. Protégé was run by hand, once per input (protege/README.txt).*

### Table 4. Query times (paper, Table 4)

| Query | Answers | SQL | GraphDB | EQL | RDFLib | Owlready2 |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: |
| Q2 | 7,421 | 1.76 | 16.4 | 42.6 | 77.3 | 115 |
| Q3 | 55 | 0.16 | 2.08 | 0.75 | 1.56 | 34.7 |
| Q4 | 2,486 | 1.64 | 6.00 | 22.7 | 65.7 | 69.3 |
| Q5 | 20 | 0.17 | 1.42 | 0.35 | 1.17 | 5.40 |
| Q7 | 1,684 | 0.68 | 4.04 | 6.91 | 17.3 | 88.8 |
| Q8 | 6 | 0.08 | 1.30 | 0.50 | 1.04 | 34.4 |
| Q9 | 0 | 0.34 | 1.39 | 0.36 | 0.98 | 0.41 |
| Q10 | 666 | 0.28 | 2.25 | 14.9 | 8.87 | 58.1 |
| Q11 | 2,422 | 0.61 | 5.13 | 24.1 | 24.1 | 62.9 |
| Q12 | 2,494 | 8.61 | 5.55 | 13.4 | 19.7 | 70.6 |
| Q13 | 0 | 0.71 | 1.60 | 0.30 | 0.98 | 0.47 |
| Q14 | 0 | 0.19 | 1.19 | 0.29 | 0.94 | 0.47 |
| Q15 | 21 | 0.14 | 1.10 | 7.64 | 1.17 | 22.8 |
| Q16 | 21 | 0.12 | 1.25 | 0.49 | 1.14 | 21.0 |
| Q19 | 858 | 2.48 | 3.06 | 2.29 | 7.29 | 34.2 |
| Q20 | 1,311,932 | 1015 | 1917 | 5873 | 22478 | 1762 |
| Q21 | 145 | 5.84 | 1.83 | 58.1 | 30.7 | 5.65 |
| Q22 | 106 | 9.38 | 1.36 | 214 | 1386 | 4.38 |
| Geom. mean |  | 0.98 | 3.47 | 5.93 | 11.0 | 18.7 |

*Query times in milliseconds on the loaded data (mean over the repetitions of this run): EQL over the objects in working memory, SQL (SQLAlchemy) over the objects that ORMatic persisted in PostgreSQL, the others over their own stores. "Answers" is the number of GraphDB's answers. The geometric means are over the 18 queries that every listed system completed, in this run.*

### Table 5. Why the ablation does not finish: eager chaining on small data

| n | Time [s] | Attempts | Facts | Complete |
| ---: | ---: | ---: | ---: | :--- |
| 8 | 0.36 | 622 | 64 | yes |
| 16 | 0.38 | 4,822 | 256 | yes |
| 32 | 0.52 | 38,332 | 1,024 | yes |
| 64 | 1.57 | 306,037 | 4,096 | yes |
| 128 | 10.1 | 2,447,152 | 16,384 | yes |
| 256 | 74.9 | 19,574,230 | 65,536 | yes |

*Eager chaining (the ablation "KRROOD without step 5") on the OWL2Bench TBox plus n persons who share a home town, linked in a chain: load time, attempts to add a fact, facts (n², everyone with everyone) and whether the closure is complete. The attempts grow about 8-fold per doubling of n, i.e. cubically; OWL2Bench's largest such group has 1,145 persons, which explains why the ablation does not finish within two hours on the benchmark (Table 3).*

### Table 6. Query size in EQL, SPARQL and SQLAlchemy (supplement only)

| Query | SPARQL | EQL without domain=None | EQL | SQLAlchemy |
| :--- | ---: | ---: | ---: | ---: |
| Q2 | 10 | 25 | 29 | 31 |
| Q3 | 10 | 25 | 29 | 6 |
| Q4 | 10 | 26 | 30 | 30 |
| Q5 | 9 | 15 | 17 | 6 |
| Q7 | 10 | 25 | 29 | 6 |
| Q8 | 10 | 25 | 29 | 6 |
| Q9 | 9 | 39 | 43 | 51 |
| Q10 | 10 | 25 | 29 | 6 |
| Q11 | 10 | 25 | 29 | 6 |
| Q12 | 9 | 22 | 26 | 6 |
| Q13 | 9 | 15 | 19 | 6 |
| Q14 | 9 | 15 | 19 | 6 |
| Q15 | 9 | 22 | 26 | 14 |
| Q16 | 9 | 22 | 26 | 14 |
| Q19 | 9 | 15 | 19 | 6 |
| Q20 | 10 | 25 | 29 | 6 |
| Q21 | 22 | 55 | 59 | 80 |
| Q22 | 26 | 62 | 70 | 108 |
| Total | 200 | 483 | 557 | 394 |
| Geometric mean | 10.5 | 24.7 | 28.8 | 12.1 |

*Lexical tokens of each benchmark query as the benchmark code writes it (tools/query_size.py): SPARQL without its PREFIX declarations; EQL and SQLAlchemy as the Python statements that build the query. "EQL" counts domain=None, which the version of KRROOD of the experiments needs and the current one does not; "EQL without domain=None" omits it. The EQL queries are longer than SPARQL's on every query, mostly because every variable is declared with its class; they are shorter than SQLAlchemy's on Q2, Q4, Q9, Q21 and Q22, where SQLAlchemy names join tables, keys or conditions on columns. Size says nothing about how easy a query is to read or to get right; the paper makes no claim about it.*

